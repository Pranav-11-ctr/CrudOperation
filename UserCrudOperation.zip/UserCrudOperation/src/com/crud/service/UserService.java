package com.crud.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.crud.model.User;

public class UserService implements UserCrud {

	@Override
	public int insertUser(User user)  {
		int result=0;
		try {
		Connection con=UserConnection.getConnection();
		 
			PreparedStatement ps=con.prepareStatement("insert into userDetails(userId,userName,password) values(?,?,?)");
			ps.setInt(1,user.getUserId());
			ps.setString(2,user.getName());
			ps.setString(3,user.getPassword());
			result=ps.executeUpdate();
			con.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return result;
	}

	@Override
	public int updateUser(User user) {
		int result=0;
		try
		{
			Connection con=UserConnection.getConnection();
			PreparedStatement ps=con.prepareStatement("update userDetails set userId=?,userName=?,password=?");
			ps.setInt(1, user.getUserId());
			ps.setString(2,user.getName());
			ps.setString(3,user.getPassword());
			result=ps.executeUpdate();
			con.close();
		}catch(Exception e)
		{
			
		}
		
		return result;
	}

	@Override
	public int deleteUser(int userId) {
		int result=0;
		try
		{
			Connection con=UserConnection.getConnection();
			PreparedStatement ps=con.prepareStatement("delete from userDetails where userId=?");
			ps.setInt(1,userId);
			result=ps.executeUpdate();
			con.close();
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return result;
	}

	@Override
	public List<User> getAllUser() {
		ArrayList<User> list=new ArrayList<>();
		try
		{
			Connection con=UserConnection.getConnection();
			Statement stmt=con.createStatement();
			ResultSet set=stmt.executeQuery("Select * from userDetails");
			
			while(set.next())
			{
				list.add(new User(set.getInt(1),set.getString(2),set.getString(3)));
				
			}
			stmt.close();
			con.close();
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return list;
	}

	@Override
	public User getUserById(int userId) {
		User user=null;
		try
		{
			Connection con=UserConnection.getConnection();
			PreparedStatement ps=con.prepareStatement("Select * from userDetails where userId=?");
			ps.setInt(1,userId);
			ResultSet set=ps.executeQuery();
			if(set.next())
			{
				user=new User(set.getInt(1),set.getString(2),set.getString(3));
			}
			con.close();
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return user;
	}

}
