package com.crud.service;

import java.util.List;

import com.crud.model.User;

public interface UserCrud {
	
	int insertUser(User user);
	int updateUser(User user);
	int deleteUser(int userId);
	List<User> getAllUser();
	User getUserById(int userId);
	

}
