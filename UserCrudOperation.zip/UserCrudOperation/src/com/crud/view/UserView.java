package com.crud.view;

import java.util.List;
import java.util.Scanner;

import com.crud.contoller.UserController;
import com.crud.model.User;

public class UserView {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int ch;
		int uid;
		String name;
		String pswd;
		int result;
		UserController userCtrl=new UserController();;
		User user=null;
		while(true)
		{
			System.out.println("1 Insert User");
			System.out.println("2 Update User");
			System.out.println("3 Delete User");
			System.out.println("4 View User");
			System.out.println("5 View a User");
			System.out.println("Enter 0 to exit");
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter your choice");
			 ch = sc.nextInt();
			 
			 switch(ch)
			 {
			 case 0:System.exit(0);
			 		break;
			 case 1:
				 	System.out.println("Enter UserId , Username , password");
				 	uid=sc.nextInt();
				 	sc.nextLine();
				 	name=sc.nextLine();
				 	pswd=sc.nextLine();
				 	user=new User(uid,name,pswd);
				 	result=userCtrl.insertUser(user);
				 	if(result>0)
				 	{
				 		System.out.println("User inserted");
				 	}
				 	else
				 	{
				 		System.out.println("User Not insertd");
				 	}
				 	break;
			 case 2:
				    System.out.println("Enter UserId , Username , password");
				 	uid=sc.nextInt();
				 	sc.nextLine();
				 	name=sc.nextLine();
				 	pswd=sc.nextLine();
				 	user=new User(uid,name,pswd);
				 	result=userCtrl.updateUser(user);
				 	if(result>0)
				 	{
				 		System.out.println("User Updated");
				 	}
				 	else
				 	{
				 		System.out.println("User Not Updated");
				 	}
				 	break;
			 case 3:
				 	System.out.println("Enter UserId");
				 	uid=sc.nextInt();
				 	result=userCtrl.deleteUser(uid);
				 	if(result>0)
				 	{
				 		System.out.println("User deleted");
				 	}
				 	else
				 	{
				 		System.out.println("User not deleted");
				 	}
				 	break;
			 case 4:
				 List<User> list=userCtrl.getAllUser();
				 for(User usr:list) {
					 System.out.println(usr.getUserId()+"\t"+usr.getName()+"\t"+usr.getPassword());
				 }
				 break;
			 case 5:
				 	System.out.println("Enter UserId");
				 	uid=sc.nextInt();
				 	user=userCtrl.getUserById(uid);
				 	System.out.println("UserId "+user.getUserId());
				 	System.out.println("Username "+user.getName());
				 	System.out.println("Password "+user.getPassword());
				 	
				 	
				 	
			 }
			
		}

	}

}
