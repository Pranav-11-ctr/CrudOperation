package com.crud.contoller;

import java.util.List;

import com.crud.model.User;
import com.crud.service.UserService;

public class UserController {
	UserService userService;
	
	public UserController()
	{
		userService=new UserService();
	}
	
	public int insertUser(User user) {
		// TODO Auto-generated method stub
		int result=userService.insertUser(user);
		return result;
	}


	public int updateUser(User user) {
		// TODO Auto-generated method stub
		int result=userService.updateUser(user);
		return result;
	}

	public int deleteUser(int userId) {
		// TODO Auto-generated method stub
		int result=userService.deleteUser(userId);
		return result;
	}

	public List<User> getAllUser() {
		// TODO Auto-generated method stub
		List<User> list=userService.getAllUser();
		return list;
	}


	public User getUserById(int userId) {
		// TODO Auto-generated method stub
		User user=userService.getUserById(userId);
		return user;
	}	

}
