package com.crud.view;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import com.crud.controller.StudentController;
import com.crud.model.Student;

public class StudentView {
	public static void main(String[] args) throws Exception
	{
		int choice;
		int rollno;
		String name;
		Date dob;
		Student student;
		int result;
		StudentController studentctrl=new StudentController();
		while(true)
		{
			System.out.println("1. Add Record");
			System.out.println("2. Update Record");
			System.out.println("3. Delete Record");
			System.out.println("4. View Record");
			System.out.println("5. View a Record");
			System.out.println("Enter 0 to exit");
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter your choice");
			choice=sc.nextInt();
			
			switch(choice)
			{
			case 1:
				System.out.println("Enter rollno , name , dob");
				rollno=sc.nextInt();
				sc.nextLine();
				name=sc.nextLine();
				dob=new SimpleDateFormat("yyyy-MM-dd").parse(sc.nextLine());
				 student = new Student(rollno,name,dob);
				 result=studentctrl.insertRecord(student);
				 if(result>0)
				 {
					 System.out.println("Record Inserted");
				 }
				 else
				 {
					 System.out.println("Record not inserted");
				 }
				 break;
				 
			case 2:
				System.out.println("Enter rollno , name , dob");
				rollno=sc.nextInt();
				sc.nextLine();
				name=sc.nextLine();
				dob=new SimpleDateFormat("yyyy-MM-dd").parse(sc.nextLine());
				student =new Student(rollno,name,dob);
				result=studentctrl.updateRecord(student);
				if(result>0)
				{
					System.out.println("Record Updated");
				}
				else
				{
					System.out.println("Record not updated");
				}
				break;
			case 3:
				System.out.println("Enter Rollno");
				rollno=sc.nextInt();
				result=studentctrl.deleteRecord(rollno);
				if(result>0)
				{
					System.out.println("Record deleted");
				}
				else
				{
					System.out.println("Record not deleted");
				}
				break;
				
			case 4:
				List<Student> list=studentctrl.getAllRecords();
				for(Student stud:list)
				{
					System.out.println(stud.getRollno()+"\t"+stud.getStudname()+"\t"+stud.getDob());
					
				}
				break;
				
		   case 5:
			   System.out.println("Enter rollno");
			   rollno=sc.nextInt();
			   student=studentctrl.getStudentByRollno(rollno);
			   System.out.println("RollNo = "+student.getRollno());
			   System.out.println("Name = "+student.getStudname());
			   System.out.println("DOB = "+student.getDob());
			   break;
		   case 0:
			   System.exit(0);
				
			}
			
				
		}
	}

}
