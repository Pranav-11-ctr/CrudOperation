package com.crud.service;

import java.util.ArrayList;

import com.crud.model.Student;

public class StudentService {

	public ArrayList<Student> getAllRecords() {
		// TODO Auto-generated method stub
		return null;
	}

	public int insertRecord(Student student) {
		// TODO Auto-generated method stub
		return 0;
	}

	public int deleteRecord(int rollNo) {
		// TODO Auto-generated method stub
		return 0;
	}

	public int updateRecord(Student student) {
		// TODO Auto-generated method stub
		return 0;
	}

	public Student getStudentByRollno(int rollNo) {
		// TODO Auto-generated method stub
		return null;
	}

}
