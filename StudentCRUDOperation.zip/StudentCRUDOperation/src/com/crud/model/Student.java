package com.crud.model;

import java.util.Date;

public class Student {
	private int rollno;
	private String studName;
	private Date dob;
	public int getRollno() {
		return rollno;
	}
	public void setRollno(int rollno) {
		this.rollno = rollno;
	}
	public String getStudName() {
		return studName;
	}
	public void setStudName(String studName) {
		this.studName = studName;
	}
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}
	public Student(int rollno, String studName, Date dob) {
		super();
		this.rollno = rollno;
		this.studName = studName;
		this.dob = dob;
	}
	
	

}
