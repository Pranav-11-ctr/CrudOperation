package com.crud.service;

import java.util.List;

import com.crud.model.Admin;

public interface AdminCrud {
	int insertAdmin(Admin admin);
	int updateAdmin(Admin admin);
	int deleteAdmin(int adminId);
	List<Admin> getAllAdmin();
	Admin getAdminById(int adminId);
	

}
