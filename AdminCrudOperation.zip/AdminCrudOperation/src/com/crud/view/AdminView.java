package com.crud.view;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.crud.contoller.AdminController;
import com.crud.model.Admin;

public class AdminView {

	public static void main(String[] args) {
		int ch;
		int aid;
		String aName;
		String pswd;
		Admin admin=null;
		int result;
		AdminController adctrl=new AdminController();
		
		while(true)
		{
			System.out.println("1. Insert Admin");
			System.out.println("2. Update Admin");
			System.out.println("3. Delete Admin");
			System.out.println("4. View Admin");
			System.out.println("5. View a admin");
			System.out.println("Enter 0 to exit");
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter your choice");
			ch=sc.nextInt();
			
			switch(ch)
			{
			case 1:
				System.out.println("Enter AdminId, AdminName , password");
				aid=sc.nextInt();
				sc.nextLine();
				aName=sc.nextLine();
				pswd=sc.nextLine();
				admin=new Admin(aid,aName,pswd);
				result=adctrl.insertAdmin(admin);
				if(result>0)
				{
					System.out.println("Admin inserted");
				}else
				{
					System.out.println("Admin not inserted");
				}
					
					break;
					
			case 2:
				
				System.out.println("Enter AdminId, AdminName , password");
				aid=sc.nextInt();
				sc.nextLine();
				aName=sc.nextLine();
				pswd=sc.nextLine();
				admin=new Admin(aid,aName,pswd);
				result=adctrl.updateAdmin(admin);
				if(result>0)
				{
					System.out.println("Admin updated");
				}else
				{
					System.out.println("Admin not updated");
				}
				
					break;
			case 3:
				System.out.println("Enter adminid");
				aid=sc.nextInt();
				result=adctrl.deleteAdmin(aid);
				if(result>0)
				{
					System.out.println("Admin Deleted");
				}else
				{
					System.out.println("Admin not deleted");
				}
				
					break;
			case 4:
				List<Admin> list=adctrl.getAllAdmin();
				for(Admin admn:list)
				{
					System.out.println("Admin Id : "+admn.getAdminId()+"\n Admin Name : "+admn.getName()+"\n Admin Password : "+admn.getPassword());
				}
				
					break;
			case 5:
				
				System.out.println("Enter Admin Id");
				aid=sc.nextInt();
				admin=adctrl.getAdminById(aid);
				System.out.println("Admin Id : "+admin.getAdminId()+"\nAdmin Name : "+admin.getName()+"\nAdmin Password : "+admin.getPassword());
					break;
			case 0:
				System.exit(0);
					break;
			}
		}

	}

}
