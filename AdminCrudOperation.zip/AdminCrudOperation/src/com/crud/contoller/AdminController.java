package com.crud.contoller;

import java.util.List;

import com.crud.model.Admin;
import com.crud.service.AdminService;

public class AdminController {
	
	AdminService adminService;
	
	public AdminController()
	{
		adminService=new AdminService();
	}
	public int insertAdmin(Admin admin) {
		int result=adminService.insertAdmin(admin);
		return result;
	}

	
	public int updateAdmin(Admin admin) {
		int result=adminService.updateAdmin(admin);
		return result;
	}

	
	public int deleteAdmin(int adminId) {
		int result=adminService.deleteAdmin(adminId);
		return result;
	}

	
	public List<Admin> getAllAdmin() {
		List<Admin> list=adminService.getAllAdmin();
		return list;
	}


	public Admin getAdminById(int adminId) {
		Admin admin=adminService.getAdminById(adminId);
		return admin;
	}


}
