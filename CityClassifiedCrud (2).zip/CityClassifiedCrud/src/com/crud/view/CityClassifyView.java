package com.crud.view;

import java.util.List;
import java.util.Scanner;

import com.crud.controller.CityClassifyController;
import com.crud.model.CityClassified;

public class CityClassifyView {

	public static void main(String[] args) {
		int ch;
		int id;
		String cno;
		String desc;
		CityClassified cca = null;
		int result;
		CityClassifyController ccc = new CityClassifyController();

		while (true) {
			System.out.println("1. Insert CityClassify");
			System.out.println("2. Update CityClassify");
			System.out.println("3. Delete CityClassify");
			System.out.println("4. View CityClassify");
			System.out.println("5. View a CityClassify");
			System.out.println("Enter 0 to exit");
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter your choice");
			ch = sc.nextInt();

			switch (ch) {
			case 1:
				System.out.println("Enter Id, contact_no , description");
				id = sc.nextInt();
				sc.nextLine();
				cno = sc.nextLine();
				desc = sc.nextLine();
				cca = new CityClassified(id, cno, desc);
				result = ccc.insertCityClassify(cca);
				if (result > 0) {
					System.out.println("CityClassify inserted");
				} else {
					System.out.println("CityClassify not inserted");
				}

				break;

			case 2:
				System.out.println("Enter Id, contact_no , description");
				id = sc.nextInt();
				sc.nextLine();
				cno = sc.nextLine();
				desc = sc.nextLine();
				cca = new CityClassified(id, cno, desc);
				result = ccc.updateCityClassify(cca);
				if (result > 0) {
					System.out.println("CityClassify updated");
				} else {
					System.out.println("CityClassify not updated");
				}
				break;
			case 3:
				System.out.println("Enter CityClassifyid");
				id = sc.nextInt();
				result = ccc.deleteCityClassify(id);
				if (result > 0) {
					System.out.println("CityClassify Deleted");
				} else {
					System.out.println("CityClassify not deleted");
				}

				break;
			case 4:
				List<CityClassified> list = ccc.getAllCityClassify();
				for (CityClassified admn : list) {
					System.out.println("CityClassify Id : " + admn.getId() + "\n CityClassify Contact number : " + admn.getContdet()
							+ "\n CityClassify description : " + admn.getDescdetl());
				}

				break;
			case 5:

				System.out.println("Enter CityClassify Id");
				id = sc.nextInt();
				cca = ccc.getAdminById(id);
				System.out.println("CityClassify Id : " + cca.getId() + "\nCityClassify Contact : " + cca.getContdet()
						+ "\nCityClassify description : " + cca.getDescdetl());
				break;
			case 0:
				System.exit(0);
				break;
			}
		}

	}

}
