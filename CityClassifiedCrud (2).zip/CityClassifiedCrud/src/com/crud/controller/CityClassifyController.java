package com.crud.controller;

import java.util.List;

import com.crud.model.CityClassified;
import com.crud.service.CityClassifyService;

public class CityClassifyController {
	CityClassifyService ccfServ;
	
	public CityClassifyController()
	{
		ccfServ=new CityClassifyService();
	}
	public int insertCityClassify(CityClassified ccf) {
		// TODO Auto-generated method stub
		int result=ccfServ.insertCityClassify(ccf);
		return result;
	}

	public int updateCityClassify(CityClassified ccf) {
		// TODO Auto-generated method stub
		int result=ccfServ.updateCityClassify(ccf);
		return result;
	}

	public int deleteCityClassify(int ccfId) {
		// TODO Auto-generated method stub
		int result=ccfServ.deleteCityClassify(ccfId);
		return result;
	}

	public List<CityClassified> getAllCityClassify() {
		// TODO Auto-generated method stub
		List<CityClassified> list=ccfServ.getAllCityClassify();
		return list;
	}


	public CityClassified getAdminById(int ccfId) {
		// TODO Auto-generated method stub
		CityClassified ccf1=ccfServ.getCityClassifyById(ccfId);
		return ccf1;
	}

}
