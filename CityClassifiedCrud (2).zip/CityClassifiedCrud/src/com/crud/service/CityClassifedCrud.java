package com.crud.service;

import java.util.List;

import com.crud.model.CityClassified;

public interface CityClassifedCrud {
	int insertCityClassify(CityClassified ccf);
	int updateCityClassify(CityClassified ccf);
	int deleteCityClassify(int ccfId);
	List<CityClassified> getAllCityClassify();
	CityClassified getCityClassifyById(int ccfId);
	

}
