package com.crud.model;

public class CityClassified {
	private int id;
	private String contdet;
	private String descdetl;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getContdet() {
		return contdet;
	}
	public void setContdet(String contdet) {
		this.contdet = contdet;
	}
	public String getDescdetl() {
		return descdetl;
	}
	public void setDescdetl(String descdetl) {
		this.descdetl = descdetl;
	}
	public CityClassified(int id, String contdet, String descdetl) {
		super();
		this.id = id;
		this.contdet = contdet;
		this.descdetl = descdetl;
	}
	
	

}
